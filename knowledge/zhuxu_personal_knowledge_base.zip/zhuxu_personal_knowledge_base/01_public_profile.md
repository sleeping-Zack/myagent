---
id: public-profile
title: 朱旭公开候选人画像
type: profile
visibility: public
confidence: confirmed
updated_at: 2026-07-11
---

# 朱旭

南昌大学软件工程本科生，2027 届，目标方向为 **Agent 应用开发、RAG、AI 应用后端和 Python 后端**。

## 简介

主要关注大模型能力如何进入真实应用系统，而不是停留在单次模型调用。项目覆盖中文情绪分析、企业机器人智能客服平台二次开发、RAG 混合检索、多工具 Agent、Agent Harness、HITL 审批、答案验证、运行追踪和离线评测。

当前主打项目 `agentproject` 将 ReAct 执行面和请求级控制面分离，通过 AgentRunner、BudgetManager、ToolPolicy、ApprovalStore、AnswerVerifier、ArtifactStore 和 Trace 对 Agent 的权限、成本、质量和可追溯性进行治理。

## 教育

- 南昌大学软件学院
- 软件工程本科
- 2023.09—2027.07
- 2027 届

## 求职方向

- Agent / LLM 应用开发
- RAG / 企业知识库
- AI 应用后端
- Python 后端
- Agent 平台和大模型评测

## 主要能力

- Python、FastAPI、Django、Pydantic、RESTful API、SSE
- LangChain、ReAct、Tool Calling、MCP JSON-RPC
- PDF/TXT 文档加载、Chunk、Embedding、Chroma
- Dense + BM25 + RRF、可选 Reranker、引用溯源
- AgentRunner、AgentState、Budget、ToolPolicy、HITL
- AnswerVerifier、Artifact、Trace、Metrics、Golden Set
- pytest、FakeBackend、CI、Docker、Nginx
- MySQL、SQLite、Redis 基础
- Java/Spring Boot、Vue/TypeScript 存量项目二次开发

## 项目

### 智扫通机器人智能客服 Agent

面向扫地和扫拖机器人售后问答、环境适配、设备记录查询和报告生成的 RAG + 多工具 Agent。重点实现运行预算、动态工具权限、敏感审批、证据校验、Trace、Artifact 和评测门禁。

### 法奥机器人智能客服平台

南昌大学与法奥机器人的校企合作项目。基于 AIFlowy 进行企业级二次开发，参与智能问答、Agent 规划与执行、QA 数据闭环、工单流程、用户端交互和私有化部署链路。

### 情绪分析日记与 AI 心情助手

基于 Django 和中文文本分类模型实现情绪记录、情绪判断、趋势图和激励语录，完成早期模型到 Web 应用的端到端实践。

### IoT 边缘—云数据同步监控平台

课程团队项目。负责云端归档、存储过程和日报、DRF 接口、告警与同步控制。

## 经历说明

目前没有可确认的正式实习经历。公开资料会明确区分个人项目、校企合作、课程项目和组织经历。
