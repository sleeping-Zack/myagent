---
id: timeline
title: 经历时间线
type: timeline
visibility: public
confidence: mixed
updated_at: 2026-07-11
---

# 2023.09

进入南昌大学软件学院软件工程专业。

# 2024

- 学习 Python、C、Java、数据库、数据结构、操作系统和计算机网络
- 第十五届蓝桥杯大学 A 组省二等奖
- 逐步参与创新实践和课程项目

# 2025

## mood_tracker

完成 Django 情绪分析日记和 AI 心情助手，建立模型到 Web 应用的完整链路。

## iot-platform

参与 IoT 边缘—云数据同步监控平台，负责云端归档、存储过程、报表、DRF API 和同步控制。

## agentproject 启动

从扫地机器人知识问答开始，逐步增加 RAG、工具调用和工程治理。

## 组织经历

历史简历记录 2025.09 起担任创新创业孵化基地负责人。

# 2026.01—2026.06

参与南昌大学 × 法奥机器人校企合作，基于 AIFlowy 开展机器人智能客服平台二次开发。

# 2026.06—2026.07

集中升级 `agentproject`：

- 模型路由和熔断
- Trace 和 Metrics
- Prompt 版本
- 多租户
- SSE
- Agent Harness
- Budget
- ToolPolicy
- HITL
- AnswerVerifier
- Artifact
- Retrieval Annotation
- CI 和评测

# 2026.07

- 准备实习和秋招
- 求职方向收敛为 Agent / RAG / AI 应用后端
- 建设个人 Agent 招聘网站
