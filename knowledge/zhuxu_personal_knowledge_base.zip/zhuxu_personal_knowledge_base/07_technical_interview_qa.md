---
id: technical-qa
title: 技术面试问答索引
type: faq
visibility: public
confidence: mixed
updated_at: 2026-07-11
---

# Agent 与 Harness

## ReAct Agent 和 Harness 有什么区别

ReAct 是模型驱动的执行机制，决定何时思考和调用工具。Harness 是请求级确定性控制层，负责预算、权限、审批、状态、验证、Trace 和 Artifact。二者分别解决“怎么执行”和“执行边界是什么”。

## 为什么不能把控制逻辑都写在 Prompt 里

Prompt 不是可靠的强制边界。模型可能忽略、误解或被注入攻击影响。权限、预算和审批必须在模型之外由代码执行。

## BudgetManager 为什么需要预留

调用前预留可以保证剩余额度足够，避免并发或多轮调用在执行完成后才发现超限。成功后提交实际用量，失败则释放。

## HITL 如何设计

敏感工具请求先生成审批记录，返回 pending_approval。具备 operator 或 admin 权限的人批准后，系统校验租户、工具和参数，再恢复执行。

## MCP 会不会绕过 ToolPolicy

不能。MCP `tools/call` 必须进入同一 ToolPolicy 和 ApprovalStore，否则外部入口会绕过治理边界。

# RAG

## 为什么纯 Dense 对型号和部件名召回差

Embedding 更擅长语义相似，对型号、错误码和精确词可能弱。BM25 对词面匹配更敏感，因此通过 Dense + BM25 双路召回再用 RRF 融合。

## RRF 的优点

不要求不同检索器分数同尺度，只使用排名进行融合，适合组合 Dense 和 BM25。

## 为什么需要 Reranker

第一阶段召回追求覆盖，Reranker 使用 Query—Document 交互模型提高 Top K 排序精度，但会增加延迟和成本。

## 如何构建 Retrieval Golden Set

1. 固定语料和版本
2. Dense、BM25、Hybrid 生成候选并集
3. 人工进行 0—3 级相关性标注
4. 校验标注完整性
5. 固定随机种子划分 dev/test
6. 计算 Recall、MRR、nDCG

## 为什么不能用答案关键词自动标注

会把当前检索或答案逻辑当成真值，形成自证循环，无法真实评价相关性。

## 30 条样本够吗

只能用于快速回归和方向判断，不足以证明广泛泛化。需要扩大问题类型、增加独立 test、做置信区间和 Bad Case 分类。

# Evaluation

## Tool Recall 是什么

在需要调用特定工具的样本中，系统是否正确调用了预期工具。

## Keyword Recall 的局限

只能检查答案是否包含预期关键词，不能充分评价事实正确性和完整性，因此需要 Evidence、引用、人工评审或 LLM Judge。

## LLM-as-Judge 的风险

存在模型偏好、提示敏感、同源偏差和稳定性问题。应使用固定 rubric、独立模型、抽样人工复核和版本记录。

# FastAPI / SSE

## 为什么用 SSE 而不是 WebSocket

聊天主要是服务器单向持续输出，SSE 实现简单、支持 HTTP 基础设施和自动重连。需要双向实时控制时再考虑 WebSocket。

## SSE 为什么会被 Nginx 中断

代理缓冲、读取超时、心跳缺失和上游连接配置都可能导致断流，需要关闭缓冲、增加 proxy_read_timeout 并发送 heartbeat。

# Testing

## 为什么使用 FakeBackend

隔离模型不确定性和 API 费用，使状态机、预算、审批、验证等核心控制逻辑可以确定性测试。

## 如何测试 Prompt Injection

准备恶意输入和恶意检索片段，验证模型输入安全检查、检索污染扫描、工具权限和输出拒绝是否按预期工作。

# Database

## SQLite 的优点和局限

优点是零运维、便于本地演示和测试。局限是并发写、分布式部署、权限和运维能力有限。生产环境可以迁移 PostgreSQL、Redis 和对象存储。

## IoT 项目为什么用 Trigger 和 Procedure

课程目标是展示数据库内过程化逻辑。触发器适合插入后自动告警和入队，存储过程用于批量同步和日报。但实际大型系统也要考虑可观测性、可测试性和业务逻辑分层。

# mood_tracker

## 当前代码有什么明显问题

模型标签映射可能不正确，领域不匹配，中性情绪缺少数据依据，多用户隔离和隐私安全不足。

# farino

## 如何证明不是只修改页面

通过提交和 Diff 展示动态规划、路由、QA 数据闭环、SSE 配置和接口联调；同时明确上游框架与个人贡献。

## 如何快速理解大型陌生项目

先找启动入口、模块边界、核心实体和请求链路，再通过一个具体功能从前端事件追到 API、Service、数据库和响应。
