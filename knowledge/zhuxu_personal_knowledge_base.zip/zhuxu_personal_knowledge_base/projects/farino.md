---
id: project-farino
title: 法奥机器人智能客服平台
type: project
project_slug: farino
visibility: public
confidence: mixed
importance: high
repository: https://github.com/sleeping-Zack/farino
period: 2026.01-2026.06
status: completed
tags: [AIFlowy, Java, SpringBoot, Vue3, Agent, QA, SSE, Docker]
---

# 1. 项目性质

- 南昌大学 × 法奥机器人校企合作
- 基于 AIFlowy 大型 AI 应用平台进行二次开发
- 不是从零独立开发整个 AIFlowy
- 当前简历角色：Agent 后端开发

# 2. 当前简历技术栈

- Java
- Spring Boot
- MyBatis-Flex
- Vue 3
- MySQL
- Redis
- Qwen
- SSE
- Docker
- Nginx

# 3. 业务目标

面向机器人技术咨询、资料检索和售后服务，构建包含：

- 智能问答
- Agent 任务规划
- QA 数据沉淀
- 售后工单
- 管理端
- 用户端
- 私有化部署

的客服工作台。

# 4. 当前简历个人工作

## Direct / Agentic 两级路由

针对简单问题也进入完整 Agent 流程的问题：

- 规则判断
- Qwen 意图识别
- 普通寒暄直接交给对话模型
- 复杂请求进入知识库、Workflow、插件和 MCP 链路

该能力需在面试中说明路由规则、误判处理和降级策略。

## 动态规划模块

- 根据问题和 Bot 已绑定能力生成 3—5 步计划
- 校验工具类型、工具 ID 和参数
- 异常降级
- 通过 SSE 同步计划生成、步骤执行和完成状态

## QA 数据闭环

- 从历史会话抽取 User—Assistant 问答对
- 消息配对
- 低质量过滤
- message_id 幂等去重
- 人工审核
- Markdown 批量导出
- 优质问答回流知识库

GitHub 最新提交可确认问答精选管理、审核、标签、导出 Markdown 和知识库导入功能。

## 售后工单

当前简历记录：

- 问题类型
- 优先级
- 待处理
- 处理中
- 待补充
- 已解决
- 已关闭
- 用户身份数据隔离

该模块在本次 GitHub 抽样中未充分核验，属于 `resume_current`，上线前应补充对应文件和演示证据。

## 部署

当前简历记录：

- Docker Compose 编排后端、前端、MySQL、Redis
- Nginx API 反向代理
- 静态资源
- SSE 长连接
- 企业内网私有化部署

GitHub 提交可确认 Nginx SSE 超时配置；完整私有化部署效果需要补充部署文档或截图。

# 5. GitHub 可确认的改动方向

- Plan 层更新
- Execution 层更新
- 工作流步骤显示
- 根据工具判断规划
- Markdown 渲染和输出美化
- Token 计量
- 聊天底部固定和自动滚动
- 新消息浮动按钮
- 助手市场与侧边栏状态同步
- SSE Nginx 配置
- 问答精选管理
- Markdown 导出
- 知识库导入

# 6. RAG 和 7000+ 页口径

旧简历曾写：

- PDF 图文解析
- 文档上传、切分、向量化和问答生成
- 支持 7000+ 页或 7000+ PDF 文档

当前最新版简历重点已转为 Agent 路由、规划、QA 数据闭环和工单。

“7000+”存在“页”和“文档”两种版本，不可直接公开。必须确认：

- 是 7000 页还是 7000 份文件
- 文档来源和脱敏方式
- 是否真实完成入库
- 检索和解析效果
- 个人实际负责范围

# 7. 正确的贡献边界

推荐：

> 我在 AIFlowy 现有平台上负责 Agent 和客服工作台相关二次开发，重点包括路由、动态规划、SSE 状态同步、QA 数据闭环、聊天交互和部署链路。

禁止：

- 独立开发整个 AIFlowy
- 负责所有 Java 后端架构
- 是上游框架核心作者
- 从零设计所有 Bot、Workflow、知识库和 MCP 模块

# 8. AI 工具使用

最新提交带 Cursor 协作署名。推荐回答：

> 在大型存量工程中，我使用 Cursor 辅助代码检索和样板代码，但功能定义、模块定位、接口联调、状态流和最终验证由我负责。

# 9. 项目价值

- 能进入大型存量工程
- 能理解 Java/Vue 前后端链路
- 能处理 Agent 规划和用户交互
- 能处理 SSE、Nginx 和状态刷新
- 能将对话日志转化为知识资产
- 能进行校企合作场景的需求落地

# 10. 风险与局限

- 个人贡献必须通过 commit / diff 划边界
- 存在回滚记录，说明迭代快，但测试和分支管理仍需提升
- 缺少公开性能指标和真实用户量
- 工单模块和完整私有化部署需进一步核验
- Java 能力不宜写成高阶熟练
