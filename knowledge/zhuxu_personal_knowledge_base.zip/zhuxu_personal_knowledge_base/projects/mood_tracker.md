---
id: project-mood-tracker
title: 情绪分析日记与 AI 心情助手
type: project
project_slug: mood_tracker
visibility: public
confidence: github_verified
importance: medium
repository: https://github.com/sleeping-Zack/mood_tracker
status: early_project
tags: [Django, NLP, Transformers, RoBERTa, Matplotlib]
---

# 1. 项目定位

用户输入日记或情绪文本，系统分析情绪、保存记录、绘制趋势图，并返回与情绪相关的激励语录。

项目价值是完成：

> 输入 → 模型推理 → 业务判断 → 数据库存储 → 趋势可视化 → 页面反馈

# 2. 技术栈

- Python
- Django
- Hugging Face Transformers
- `uer/roberta-base-finetuned-jd-binary-chinese`
- Django ORM
- Matplotlib
- HTML 模板

# 3. GitHub 已确认功能

## 情绪分析

- Transformers `pipeline`
- 中文 RoBERTa 文本分类
- 置信度阈值 0.8
- positive / negative / neutral 业务映射

## 情绪记录

- 表单接收 `mood_note`
- 调用模型
- 创建 MoodEntry
- 保存日期、文本和情绪
- 按日期查询记录

## 趋势图

- positive = 1
- neutral = 0.5
- negative = 0
- Matplotlib 生成折线图
- 保存静态图片

## 激励语录

- 根据情绪从预设语录库随机选择

# 4. README 与代码差异

README 提到“关键词推荐”，但本次公开代码核验未确认其进入主业务链路。

正确口径：

> 当前公开版本可确认情绪判断、记录、趋势图和语录生成；关键词推荐属于 README 规划或未完成能力。

旧简历曾出现 LinearSVC 五分类版本，与当前 GitHub 的 RoBERTa 版本不一致。没有对应分支时，不应混用。

# 5. 已知技术问题

- 模型可能返回 `LABEL_0` / `LABEL_1`，当前字符串判断存在映射风险
- 模型训练领域与个人情绪日记并不完全一致
- 中性情绪由低置信度推断，缺少标注数据验证
- 全部用户共用同一数据和趋势图，不适合多用户
- 每次页面访问同步重新画图
- 缺少情绪数据隐私和删除机制
- 不具备心理诊断能力
- 对危机文本缺少风险分级和安全转介

# 6. 推荐面试表述

> 这是我较早的 AI 应用项目。我使用 Django 把中文文本分类模型接入完整业务链路，实现输入、推理、数据库记录、趋势图和反馈。它也让我认识到模型标签映射、领域适配、多用户隔离和敏感数据治理的重要性。

# 7. 项目在个人成长中的作用

- 证明模型调用到 Web 产品的早期闭环
- 证明 Django 和 ORM 基础
- 证明对用户体验和可视化的关注
- 能展示从简单 AI 应用逐步演进到 Agent 工程化
