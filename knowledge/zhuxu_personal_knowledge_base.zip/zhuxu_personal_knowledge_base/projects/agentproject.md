---
id: project-agentproject
title: 智扫通机器人智能客服 Agent
type: project
project_slug: agentproject
visibility: public
confidence: github_verified
importance: flagship
repository: https://github.com/sleeping-Zack/agentproject
period: 2025.10-至今
status: ongoing
tags: [Agent, RAG, Harness, FastAPI, LangChain, Chroma, MCP, HITL, Evaluation]
---

# 1. 项目定位

面向扫地和扫拖机器人售后问答、选购咨询、环境适配、设备使用记录查询和个性化报告生成的 **RAG + 多工具 Agent + Harness 控制层**项目。

项目不止实现问答，而是集中解决 Agent 应用中的运行边界：

- 最多执行多少步骤
- 最多调用多少工具
- Token、成本和时间如何限制
- 哪些角色可以调用哪些工具
- 敏感数据何时需要人工审批
- 最终回答是否有证据
- 失败和中间产物如何留存
- 如何追踪、评测和复盘

# 2. 技术栈

- Python 3.10
- FastAPI
- Pydantic
- Streamlit
- LangChain ReAct Agent
- Chroma
- SQLite
- pytest
- SSE
- MCP JSON-RPC
- Prometheus 风格 Metrics
- OpenTelemetry 风格 Trace
- Qwen3-Max / DashScope
- text-embedding-v4
- BM25、RRF、可选 BGE Reranker

# 3. 架构分层

## 执行面

- ReactAgent
- LangChain ReAct
- RAG Service
- Tool Data Service
- Conversation Memory

## 控制面

- AgentRunner
- AgentTask
- AgentState
- BudgetManager
- ToolPolicy
- ApprovalStore
- AnswerVerifier
- ArtifactStore
- Diagnostic Trace

## 接入面

- FastAPI
- Streamlit
- MCP stdio / HTTP

## 治理面

- API Key
- tenant / role / principal
- 限流
- Prompt Injection 检测
- Trace / Metrics
- 离线评测和 CI 门禁

# 4. RAG 检索

公开代码和 README 可确认：

- PDF / TXT 文档加载
- Chroma 向量库存储
- Dense 向量召回
- BM25 召回
- RRF 融合
- 可选 Reranker
- RAG 注入过滤
- Evidence 和引用来源
- Retrieval Golden Set 标注流水线
- dev/test 确定性划分
- Recall、MRR、nDCG 等评测脚本

当前简历记录的最新数据：

- 6 份领域文档
- 326 个 Chunk
- 30 条独立测试样本
- Recall@5：80.6% → 93.3%
- MRR：0.878 → 0.933
- nDCG@5：0.768 → 0.904
- Hybrid 检索 P95：385ms

这些数值属于 `resume_current`。仓库中未检索到相同数值的结果文件，公开网站上线前应补充可复现实验报告、固定 commit、语料 manifest 和运行命令。

历史交流曾出现“5 份文档、8 条标注样本”等旧版本口径，必须以固定版本实验为准，不能混用。

# 5. Agent Harness

## AgentRunner / AgentState

统一维护：

- request_id
- session_id
- tenant_id
- user_role
- scene
- budget
- steps
- observations
- tool_calls
- artifacts
- status

## BudgetManager

当前简历和代码体现五类约束：

- max_steps
- max_tool_calls
- max_tokens
- max_cost
- deadline

采用调用前预留、调用后提交、失败释放，避免执行结束后才发现超限。

## ToolPolicy

依据：

- scene
- user_role
- tenant_id
- tool_name
- args / risk

返回：

- allow
- deny
- need_approval
- need_redaction

## HITL

敏感工具进入 ApprovalStore：

- 普通用户得到 pending_approval
- operator / admin 批准或拒绝
- 审批后校验参数和租户
- 防止 MCP 或其他入口绕过控制面

## AnswerVerifier

检查：

- 是否存在 evidence
- 是否存在引用
- 是否空答案
- 工具结果是否有效
- 是否应重试或拒答

失败时保存 verification_failure artifact。

# 6. 可观测与评测

- request / tool / model trace
- diagnostic event
- tokens、cost、evidence_ids、verifier、failure_reason
- Artifact 保存 final answer、tool results 和失败信息
- Prometheus 风格指标
- Agent Golden Set
- tool_recall
- keyword_recall
- 拒答率
- P95 延迟
- 平均成本
- failure bucket
- pytest + FakeBackend
- CI smoke / EvalGate

当前简历记录：

- 8 条在线 Agent Case
- 62 条确定性 Harness 回归用例
- 55 条 RAG Golden Set

以上数字应以仓库当前测试收集结果和评测文件为最终依据。

# 7. 安全和稳定性

- API Key 鉴权
- 租户级限流
- Prompt Injection 检测
- 检索内容污染扫描
- Semantic Cache，相似度阈值 0.92
- 审批角色校验
- 跨租户审批隔离
- 懒加载模型，避免 CI 无 Key 时导入失败
- 预算超限进入 blocked
- 验证失败进入 rejected

# 8. 个人贡献口径

推荐表述：

> 我负责项目的需求拆解、总体架构、RAG 混合检索、Harness 控制层、工具治理、审批、答案验证、Trace、Artifact、评测脚本、测试和 CI 集成。开发中使用 Claude、Cursor 辅助部分代码生成和重构，但核心方案、模块整合、问题定位和最终验证由我负责。

# 9. 最有价值的技术取舍

## 为什么 ReAct 外还要 Harness

ReAct 负责模型的推理和工具调用，但不天然解决权限、预算、审批、证据、成本和审计。Harness 将这些非确定性执行之外的规则集中到确定性控制面。

## 为什么评测要人工标注

候选分数和答案关键词不能直接作相关性标签，否则会造成自证循环。因此将候选生成、人工判断、Golden Set 和评测拆分。

## 为什么用 FakeBackend

大模型调用有成本、延迟和随机性。FakeBackend 可以确定性覆盖状态机、预算、审批和失败分支。

# 10. 已知局限

- Chroma 和 SQLite 适合单机作品，不代表分布式生产架构
- 缺少真实用户量、SLA、业务转化和线上成本
- `/chat/stream` 的当前实现更接近 SSE 事件外观，需区分完整 Token 级流式
- 标注集和 Golden Set 仍偏小
- 依赖外部模型 API
- 生产环境仍需 JWT、集中存储、队列、分布式追踪和密钥管理

# 11. 技术面试重点

1. ReAct 和 Harness 的边界
2. 预算为什么要预留
3. ToolPolicy 如何防绕过
4. HITL 如何恢复执行
5. Evidence 如何从 RAG 回流到 Verifier
6. 如何构建 Retrieval Golden Set
7. 小样本指标如何避免误导
8. SQLite / Chroma 如何演进到生产组件
9. Semantic Cache 的错误复用风险
10. Prompt Injection 和检索污染的区别
