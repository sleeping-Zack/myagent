---
id: source-registry
title: 来源登记
type: sources
visibility: private
confidence: confirmed
updated_at: 2026-07-11
---

# GitHub

- https://github.com/sleeping-Zack/agentproject
- https://github.com/sleeping-Zack/farino
- https://github.com/sleeping-Zack/mood_tracker
- https://github.com/sleeping-Zack/iot-platform

# 当前简历

优先参考 2026-07-11 上传的《朱旭简历.pdf》，求职意向为 Agent 应用开发实习生。

# 次级简历

- 朱旭agent简历.pdf
- 朱旭_简历_AgentHarness版.docx
- 朱旭_简历_AgentHarness版.pdf

# 来源优先级

1. 当前 GitHub 代码和测试
2. 当前简历
3. 本人最新明确陈述
4. 旧简历
5. 行为推断

# 冲突处理

- 新版本优先于旧版本
- 代码事实优先于营销描述
- 本人最新“无正式实习”口径优先于旧简历工作经历
- 数值必须绑定版本和实验文件
