---
id: skills-matrix
title: 技能矩阵
type: skills
visibility: public
confidence: mixed
updated_at: 2026-07-11
---

# 技能等级说明

- A：能够独立完成并接受技术追问
- B：有项目实践，能完成常见任务
- C：理解概念或有基础使用
- D：仅接触，不应写入主技能

| 技能 | 建议等级 | 证据 | 面试口径 |
|---|---:|---|---|
| Python | A- | agentproject、mood_tracker、iot-platform | 熟悉，主语言 |
| FastAPI | A- | Agent API、审批、Trace、Metrics | 能做服务化和中间件 |
| Django | B | mood_tracker、iot-platform | 熟悉基础开发 |
| Pydantic | B+ | FastAPI Schema 和 Agent 输入 | 熟悉 |
| pytest | A- | AgentRunner、审批、预算、API | 熟悉测试隔离 |
| LangChain | B+ | ReAct Agent、RAG 链路 | 熟悉应用开发 |
| RAG | A- | 混合检索、Evidence、评测 | 主技能 |
| Dense/BM25/RRF | A- | agentproject | 能解释取舍 |
| Reranker | B | 可选 BGE Reranker | 有接入理解 |
| Chroma | B+ | agentproject | 熟悉单机向量库 |
| Tool Calling | A- | 多工具 Agent | 主技能 |
| ReAct | B+ | ReactAgent | 能解释执行机制 |
| MCP JSON-RPC | B+ | initialize/list/call | 有实现经验 |
| Agent Harness | A- | Runner/State/Policy/Budget | 差异化优势 |
| HITL | B+ | ApprovalStore | 有完整流程 |
| Evaluation | B+ | Golden Set、Recall、MRR、nDCG | 有工程实践 |
| Trace/Metrics | B+ | Diagnostic Trace、Prometheus | 有实践 |
| SQLite | B+ | 会话、审批、Artifact、Trace | 熟悉 |
| MySQL | B | IoT 项目和基础知识 | 熟悉基础 |
| Redis | C+ | farino 和简历 | 了解，避免写熟练 |
| Docker | B- | 项目部署和 Compose | 有项目使用 |
| Nginx | B- | SSE、反向代理 | 有配置和排障 |
| Git/GitHub | B | 多仓库、CI、分支问题 | 熟悉日常流程 |
| Java | C+/B- | farino 二次开发 | 基础阅读和改造 |
| Spring Boot | C+/B- | AIFlowy | 有项目接触 |
| Vue/TypeScript | C+/B- | farino 用户端和管理端 | 能做功能改造 |
| C | B- | 课程和嵌入式经历 | 非主方向 |
| 算法 | B- | 蓝桥杯省二等奖 | 有基础，不是算法岗定位 |
| 分布式系统 | C | 主要为单机和平台理解 | 了解，不夸大 |
| Kubernetes | D | 无可验证证据 | 不写 |
| 模型训练/微调 | D/C- | 无主项目证据 | 不作为技能 |
