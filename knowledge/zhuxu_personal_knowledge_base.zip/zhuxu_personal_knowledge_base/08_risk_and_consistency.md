---
id: risk-consistency
title: 事实冲突与风险口径
type: governance
visibility: private
confidence: confirmed
updated_at: 2026-07-11
---

# 1. 实习经历冲突

- 旧简历：江西长冈医疗科技有限公司嵌入式软件工程师
- 最新本人陈述：没有正式实习，主要是校企合作
- 当前处理：不公开为正式实习

# 2. 法奥数据规模冲突

出现过：

- 7000+ 页 PDF
- 7000+ PDF 文档

当前处理：不公开数字，待确认单位和证据。

# 3. 法奥个人职责版本变化

旧版本偏：

- PDF 解析
- RAG 知识库链路

当前最新版偏：

- Direct / Agentic 路由
- 动态规划
- QA 数据闭环
- 工单
- 私有化部署

处理：

- 以当前仓库和最新版简历为主
- PDF/RAG 能力可以作为早期工作，但需避免同时声称负责过多核心模块
- 面试前准备 commit 对照表

# 4. agentproject 语料和评测冲突

历史出现：

- 5 份文档、8 条标注样本
- 6 份文档、30 条独立测试
- 55 条 RAG Golden Set
- 8 条在线 Agent Case、62 条 Harness 回归

处理：

- 区分 Retrieval Test、RAG Answer Golden Set、Agent Case 和 pytest 用例
- 创建统一实验清单
- 每个指标绑定 commit、数据文件和运行命令

# 5. mood_tracker 模型冲突

- 旧简历：LinearSVC 五分类
- GitHub 当前：RoBERTa 二分类 + 低置信度中性

处理：以 GitHub 当前版本为准，旧模型作为历史版本必须有代码证明。

# 6. 技能熟练度冲突

旧简历出现：

- Python 精通
- Java 掌握
- 网络、系统、数据库熟练

当前建议：

- Python：熟悉
- FastAPI / RAG / Agent：熟悉且有项目
- Django：有项目实践
- Java / Vue：基础阅读和二次开发
- Redis / Docker / Nginx：了解或有项目使用
- 不使用“精通”

# 7. AI 编程工具风险

提交中有 Claude、Cursor 协作署名。

处理：

- 主动承认辅助使用
- 能解释核心代码
- 能现场修改和调试
- 不把生成文档当成掌握证明

# 8. 当前简历可保留的高价值表述

- RAG + Tool Calling + Agent Harness
- 从 Demo 到工程化
- 工具权限、预算、Prompt Injection、Evidence、失败拒答
- pytest + FakeBackend
- Golden Set 和 P95
- AIFlowy 二次开发
- QA 数据闭环

# 9. 当前简历应谨慎的表述

- 30 条样本上的精确指标
- 55 条 Golden Set
- 62 条回归用例
- 企业内网私有化部署
- 工单完整数据隔离
- 7000+ 页或文档
- “独立设计”所有模块
