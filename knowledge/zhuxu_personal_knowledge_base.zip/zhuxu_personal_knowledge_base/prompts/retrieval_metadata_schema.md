# 推荐 Chunk 元数据

```yaml
id: unique-id
title: 文档标题
type: profile|project|skill|faq|timeline|governance
project_slug: agentproject|farino|mood_tracker|iot-platform|null
section: responsibility|architecture|result|limitation|hr_qa|technical_qa
visibility: public|private
confidence: github_verified|resume_current|self_reported|inferred|requires_confirmation
importance: flagship|high|medium|supplementary
tags: []
updated_at: 2026-07-11
```

检索必须在数据库层过滤：

- `visibility = public`
- `confidence NOT IN (requires_confirmation, excluded)`

性格类信息命中时，答案必须标记为行为推断。
