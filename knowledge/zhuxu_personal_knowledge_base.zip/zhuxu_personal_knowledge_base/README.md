---
id: kb-readme
title: 朱旭个人招聘知识库
type: manifest
visibility: public
confidence: confirmed
updated_at: 2026-07-11
---

# 朱旭个人招聘知识库

该知识库用于：

- 个人 Agent 网站的 RAG 数据源
- HR 初筛和技术面试问答
- 简历内容统一
- 项目讲解与面试复盘
- 后续持续维护个人经历

## 核心定位

**朱旭，南昌大学软件工程本科，2027 届。求职方向聚焦 Agent 应用开发、RAG、AI 应用后端和 Python 后端。**

项目优先级：

1. `agentproject`：智扫通机器人智能客服 Agent，个人主打项目
2. `farino`：法奥机器人智能客服平台，AIFlowy 二次开发
3. `mood_tracker`：情绪分析日记与 AI 心情助手
4. `iot-platform`：IoT 边缘—云数据同步监控平台

## 明确排除

以下项目不得进入公开画像、推荐项目、技能匹配和面试回答：

- 网络安全、红蓝对抗、渗透测试、攻防项目
- 鸿蒙、OpenHarmony、UNISOC、PAC 镜像和系统适配项目

这些内容仅从本次知识库中排除。本文件不能修改或删除平台内部历史记忆。

## 事实等级

| 等级 | 含义 | 公开 Agent 使用规则 |
|---|---|---|
| `github_verified` | GitHub 代码、README、提交或测试直接支持 | 可作确定事实 |
| `resume_current` | 当前简历明确写出 | 可用，但数值和经历性质需交叉验证 |
| `self_reported` | 本人明确陈述 | 可用，表述为本人经历 |
| `inferred` | 根据行为、项目轨迹作出的推断 | 只能用审慎措辞 |
| `requires_confirmation` | 存在冲突或证据不足 | 不作确定回答 |
| `excluded` | 明确排除 | 不检索、不回答 |

## 最重要的口径规则

1. 不把校企合作、课程项目、个人项目包装成正式实习。
2. 不把 AIFlowy 上游框架能力全部算作朱旭个人成果。
3. 不把“使用 Claude / Cursor 协助开发”隐藏成“全部手写”。
4. 不把少量离线样本包装成统计显著的线上效果。
5. 不把未验证的 7000+ 页、医院落地、用户量等数字作为确定事实。
6. 面试回答必须区分：参与、负责、主导、独立完成。
7. 公开 Agent 只能检索 `visibility: public` 的内容。
